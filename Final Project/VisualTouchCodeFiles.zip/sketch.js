// Global variables to store particles and settings
let particlesMain = []; // Array to hold particle objects
let colors; // Array of colors for particles
let variation = 0; // Current variation for slope calculations
let xScale, yScale, centerX, centerY; // Scaling and centering values

// Auto change settings
let changeDuration = 3000; // Duration between variation changes (milliseconds)
let lastChange = 0; // Timestamp of the last variation change

// GUI variables and settings
let gui; // Dat.GUI object for user interface
let mic; // Microphone input
let fft; // Fast Fourier Transform for audio analysis
let params = { // Object to hold GUI parameters
    size: 1, // Particle size
    color: "#00BCD4", // Particle color
    movementSpeed: 1, // Particle movement speed
    variation: 0, // Variation index for slope calculations
    Particles: false, // Toggle particle generation
    soundReactive: false, // Toggle sound reactivity
    backgroundColor: "#000000", // Background color
    colorCycleSpeed: 1, // Speed of color cycling
    reset: function() { resetSketch(); }, // Function to reset the sketch
    particleShape: "line", // Shape of particles (line, ellipse, triangle)
    particleAlpha: 255, // Alpha value of particles
    particleRotationSpeed: 0.01, // Rotation speed of particles
    particleRotation: 0, // Initial rotation of particles
    autoMouse: false, // Toggle auto mouse clicks for particle generation
};

let autoMouseTimer = 0; // Timer for auto mouse clicks
let autoMouseInterval = 100; // Interval between auto mouse clicks (milliseconds)

// Setup function: initializes canvas, variables, and GUI
function setup() {
    createCanvas(windowWidth, windowHeight); // Create canvas to fill window
    textAlign(CENTER, CENTER); // Set text alignment

    // Calculate scaling and centering values based on canvas size
    xScale = width / 20;
    yScale = height / 20 * (width / height);
    centerX = width / 2;
    centerY = height / 2;

    // Define an array of colors for particle cycling
    colors = [
        color("#FF6F61"), // Coral red
        color("#F5A623"), // Golden yellow
        color("#FF9F00"), // Amber
        color("#FF4C00"), // Deep orange
        color("#FFD700")  // Bright gold
    ];

    // Initialize microphone and FFT for sound reactivity
    mic = new p5.AudioIn();
    mic.start();
    fft = new p5.FFT();
    fft.setInput(mic);

    // Create Dat.GUI for user interface
    gui = new dat.GUI();
    gui.add(params, 'size', 0.1, 2).onChange(updateParticlesMain); // Size slider
    gui.addColor(params, 'color').onChange(updateParticlesMain); // Color picker
    gui.add(params, 'movementSpeed', 0.1, 5); // Movement speed slider
    gui.add(params, 'variation', 0, 25).step(1).onChange(updateVariation); // Variation slider
    gui.add(params, 'Particles'); // Particle toggle
    gui.add(params, 'soundReactive'); // Sound reactivity toggle
    gui.addColor(params, 'backgroundColor').onChange(updateBackground); // Background color picker
    gui.add(params, 'colorCycleSpeed', 0.1, 5).name("Color Cycle Speed"); // Color cycle speed slider
    gui.add(params, 'reset').name("Reset Sketch"); // Reset button
    gui.add(params, 'particleShape', ["line", "ellipse", "triangle"]).name("Particle Shape"); // Particle shape dropdown
    gui.add(params, 'particleAlpha', 0, 255).name("Particle Alpha"); // Particle alpha slider
    gui.add(params, 'particleRotationSpeed', -0.1, 0.1).name("Particle Rotation Speed"); // Particle rotation speed slider
    gui.add(params, 'autoMouse').name("Auto Mouse"); // Auto mouse toggle

    // Add event listener to resume audio context on click
    document.addEventListener('click', resumeAudioContext);
}

// Function to resume audio context if it's suspended
function resumeAudioContext() {
    if (getAudioContext().state !== 'running') {
        getAudioContext().resume();
    }
}

// Draw function: main loop for rendering and updating
function draw() {
    // Auto mouse click logic
    if (params.autoMouse) {
        autoMouseTimer += deltaTime;
        if (autoMouseTimer > autoMouseInterval) {
            autoMouseTimer = 0;
            let randomX = random(width);
            let randomY = random(height);
            mouseX = randomX;
            mouseY = randomY;
            mouseIsPressed = true;
            generateParticles();
            mouseIsPressed = false;
        }
    }

    // Generate particles on mouse press if enabled
    if (params.Particles && mouseIsPressed && !params.autoMouse) {
        generateParticles();
    }

    // Handle empty particle array
    if (particlesMain.length === 0) {
        background(params.backgroundColor);
        noStroke();
        fill(255);
        textSize(40);
        text("Press Particles To Start.", centerX, centerY);
        return;
    }

    // Clear background with a semi-transparent rectangle
    noStroke();
    fill(red(params.backgroundColor), green(params.backgroundColor), blue(params.backgroundColor), 10);
    rect(0, 0, width, height);

    // Auto variation change logic
    let currentTime = millis();
    if (currentTime - lastChange > changeDuration) {
        lastChange = currentTime;
        variation++;
        if (variation > 25) variation = 0;
    }

    // Sound reactivity logic
    if (params.soundReactive) {
        let spectrum = fft.analyze();
        let highFreq = fft.getEnergy("treble");
        let lowFreq = fft.getEnergy("bass");

        params.size = map(highFreq, 0, 255, 0.5, 2);
        params.movementSpeed = map(lowFreq, 0, 255, 0.5, 5);
        updateParticlesMain();
    }

    // Color cycling logic
    let colorOffset = (millis() * 0.001 * params.colorCycleSpeed) % colors.length;
    let colorIndex = floor(colorOffset);
    let nextColorIndex = (colorIndex + 1) % colors.length;
    let lerpAmount = colorOffset - colorIndex;
    params.color = lerpColor(colors[colorIndex], colors[nextColorIndex], lerpAmount);

    // Update and render particles
    let stepsize = deltaTime * 0.002;
    for (let i = particlesMain.length - 1; i >= 0; i--) {
        let particle = particlesMain[i];

        // Calculate particle movement based on slope functions
        let x = getSlopeX(particle.x, particle.y);
        let y = getSlopeY(particle.x, particle.y);
        particle.x += particle.direction * x * stepsize;
        particle.y += particle.direction * y * stepsize;

        // Convert particle coordinates to screen coordinates
        x = getXPrint(particle.x);
        y = getYPrint(particle.y);

        // Update particle rotation
        particle.rotation += params.particleRotationSpeed;

        // Set particle fill color
        fill(color(red(particle.color), green(particle.color), blue(particle.color), params.particleAlpha));

        // Render particle based on selected shape
        if (params.particleShape === "line") {
            stroke(color(red(particle.color), green(particle.color), blue(particle.color), params.particleAlpha));
            strokeWeight(particle.size);
            line(x, y, particle.lastX, particle.lastY);
        } else if (params.particleShape === "ellipse") {
            noStroke();
            ellipse(x, y, particle.size * 5, particle.size * 5);
        } else if (params.particleShape === "triangle") {
            noStroke();
            push();
            translate(x, y);
            rotate(particle.rotation);
            triangle(-particle.size * 3, particle.size * 3, 0, -particle.size * 3, particle.size * 3, particle.size * 3);
            pop();
        }

        // Update last particle coordinates
        particle.lastX = x;
        particle.lastY = y;

        // Remove particles that are out of bounds
        const border = 20
        if (x < -border || y < -border || x > width + border || y > height + border) {
            particlesMain.splice(i, 1);
        }
    }
}

// Function to generate new particles at mouse position
function generateParticles() {
    for (let i = 0; i < 20; i++) {
        let x = mouseX + random(-100, 100);
        let y = mouseY + random(-100, 100);
        let particle = {
            x: getXPos(x),
            y: getYPos(y),
            size: random(1, 5) * params.size,
            lastX: x,
            lastY: y,
            color: color(params.color),
            direction: random(0.1, 1) * (random() > 0.5 ? 1 : -1) * params.movementSpeed,
            rotation: random(TWO_PI),
        };
        particlesMain.push(particle);
    }
}

// Function to calculate slope for Y-axis movement
function getSlopeY(x, y) {
    switch (params.variation) {
        case 0: return Math.sin(x * 6);
        case 1: return Math.sin(x * 5) * y * 0.3;
        case 2: return Math.cos(x * y);
        case 3: return Math.sin(x) * Math.cos(y);
        case 4: return Math.cos(x) * y * y;
        case 5: return Math.log(Math.abs(x)) * Math.log(Math.abs(y));
        case 6: return Math.tan(x) * Math.cos(y);
        case 7: return -Math.sin(x * 0.1) * 3;
        case 8: return (x - x * x * x) * 0.01;
        case 9: return -Math.sin(x);
        case 10: return -y - Math.sin(1.5 * x) + 0.7;
        case 11: return Math.sin(x) * Math.cos(y);
        case 12: return Math.sin(x * y) * Math.cos(x - y);
        case 13: return Math.atan(x) * Math.sin(y);
        case 14: return Math.sin(x * x + y * y) * 0.1;
        case 15: return Math.sin(Math.sqrt(x * x + y * y));
        case 16: return Math.sin(x) * Math.tan(y);
        case 17: return Math.sin(x * 0.5) * Math.cos(y * 0.5) * 2;
        case 18: return Math.sin(x * x) * Math.cos(y * y);
        case 19: return Math.sin(x) + Math.cos(y);
        case 20: return Math.sin(x * y) + Math.cos(x - y);
        case 21: return Math.sin(x * y) * Math.cos(x / y);
        case 22: return noise(x * 0.1, y * 0.1) * 2 - 1;
        case 23: return 10 * (y - x);
        case 24: return Math.sin(x / y) * Math.cos(y / x);
        case 25: return Math.exp(x * 0.1) * Math.sin(y * 0.1);
        default: return Math.sin(x);
    }
}

// Function to calculate slope for X-axis movement
function getSlopeX(x, y) {
    switch (params.variation) {
        case 0: return Math.cos(y * 2);
        case 1: return Math.cos(y * 5) * x * 0.3;
        case 2:
        case 3:
        case 4:
        case 5:
        case 6: return 1;
        case 7: return Math.sin(y * 0.1) * 3;
        case 8: return y / 3;
        case 9: return -y;
        case 10: return -1.5 * y;
        case 11: return Math.sin(y) * Math.cos(x);
        case 12: return Math.cos(x * y) * Math.sin(x + y);
        case 13: return Math.atan(y) * Math.cos(x);
        case 14: return Math.cos(x * x + y * y) * 0.1;
        case 15: return Math.cos(Math.sqrt(x * x + y * y));
        case 16: return Math.cos(x) * Math.tan(y);
        case 17: return Math.cos(x * 0.5) * Math.sin(y * 0.5) * 2;
        case 18: return Math.cos(x * x) * Math.sin(y * y);
        case 19: return Math.cos(x) + Math.sin(y);
        case 20: return Math.cos(x * y) + Math.sin(x - y);
        case 21: return Math.cos(x * y) * Math.sin(y / x);
        case 22: return noise(y * 0.1, x * 0.1) * 2 - 1;
        case 23: return x * (28 - y) - x;
        case 24: return Math.cos(x / y) * Math.sin(y / x);
        case 25: return Math.exp(y * 0.1) * Math.cos(x * 0.1);
        default: return Math.cos(y);
    }
}

// Function to convert screen X-coordinate to particle X-position
function getXPos(x) {
    return (x - centerX) / xScale;
}

// Function to convert screen Y-coordinate to particle Y-position
function getYPos(y) {
    return (y - centerY) / yScale;
}

// Function to convert particle X-position to screen X-coordinate
function getXPrint(x) {
    return xScale * x + centerX;
}

// Function to convert particle Y-position to screen Y-coordinate
function getYPrint(y) {
    return yScale * y + centerY;
}

// Function to update particle properties based on GUI parameters
function updateParticlesMain() {
    for (let particle of particlesMain) {
        particle.size = random(1, 5) * params.size;
        particle.color = color(params.color);
        particle.direction = random(0.1, 1) * (random() > 0.5 ? 1 : -1) * params.movementSpeed;
    }
}

// Function to update variation index
function updateVariation() {
    variation = params.variation;
}

// Function to update background color
function updateBackground() {
    background(params.backgroundColor);
}

// Function to reset the sketch to its initial state
function resetSketch() {
    particlesMain = [];
    params.size = 1;
    params.color = "#00BCD4";
    params.movementSpeed = 1;
    params.variation = 0;
    params.Particles = false;
    params.soundReactive = false;
    params.backgroundColor = "#000000";
    params.particleShape = "line";
    params.particleAlpha = 255;
    params.particleRotationSpeed = 0.01;
    params.particleRotation = 0;
    params.autoMouse = false;
    updateParticlesMain();
}

// Function to handle window resize
function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
    centerX = width / 2;
    centerY = height / 2;
    xScale = width / 20;
    yScale = height / 20 * (width / height);
}